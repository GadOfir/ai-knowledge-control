# SLOP-PATTERNS.md - AI Writing Quality Rules

**Metadata:** [Type: Data | Strategy: `1`]
**Active Context:** [CID: CICD-04 | Task: Define slop detection patterns]

---

## Purpose

Define patterns for detecting and removing AI verbosity ("slop") from README improvements.

---

## Slop Score Calculation

```
slop_score = (filler_lines + duplicate_lines) / total_lines * 100

GREEN:  < 10% slop  (PASS)
YELLOW: 10-20% slop (WARNING)
RED:    > 20% slop  (REQUIRES CLEANUP)
```

---

## Filler Phrases to Remove

| Pattern | Example | Action |
|---------|---------|--------|
| Excitement markers | "This is amazing!" | Delete |
| Hedging words | "basically", "essentially", "actually" | Delete |
| Stating obvious | "If tests fail, tests have failed" | Delete |
| Over-explanation | "What this means is..." | Delete |
| Filler intros | "It's important to note that" | Delete |
| Redundant emphasis | "CRITICAL: This is very important" | Pick one |
| Permission asking | "Let me explain..." | Delete |
| Self-reference | "As an AI, I think..." | Delete |

---

## Duplicate Content Patterns

| Pattern | Example | Action |
|---------|---------|--------|
| Same rule in multiple sections | Validation logic repeated | Centralize, reference |
| Repeated examples | Same code block twice | Remove duplicate |
| Restated purpose | "As mentioned above..." | Delete |

---

## Formatting Slop

| Pattern | Example | Action |
|---------|---------|--------|
| Excessive emoji | "🚀 ✨ 🎉 💡" everywhere | Max 3 per section |
| Over-bolding | "**Every** **word** **bold**" | Bold key terms only |
| Verbose headers | "Key Learnings From Our Experience" | → "Key Learnings" |
| Deep nesting | 5 levels of bullets | Flatten to 2-3 |

---

## Quality Rules

1. **One validation per pipeline** - other sections reference it
2. **Examples: 10 lines max** - unless complexity requires more
3. **No filler phrases** - get to the point
4. **Emoji: max 3 per section** - visual noise otherwise
5. **Headers: 3 words or less** - when possible
6. **Key Learnings: max 5 bullets** - only novel insights
7. **No duplicate content** - link to source instead

---

## Before/After Examples

### Bad (Slop)
```markdown
## 🚀 CRITICAL: Important Production State Verification (PRE-FLIGHT) 🚀

**Rule:** It's really important to note that you should NEVER, ever analyze
a README without first verifying its production state. This is absolutely
critical and cannot be overstated. What this means is that before you do
anything else, you need to check the state.

### Why This Matters
As an AI system, I think it's essential to understand that...
```

### Good (Clean)
```markdown
## Pre-Flight Verification

**Rule:** Verify production state before analysis.

See: PRE-FLIGHT.md → PF-01
```

---

## Measurement

When analyzing README improvements, report:

```
WORDING METRICS
──────────────────────────────────────────────────
Lines:           [before] → [after] ([diff])
Filler Removed:  [count] phrases
Duplicates:      [count] eliminated
Slop Score:      [before]% → [after]% ([status])
```

---

## Integration

Phase 2 (ANALYZE) calculates slop score of current README.
Phase 3 (IMPLEMENT) applies slop reduction to improvements.
Phase 4 (REPORT) shows before/after wording metrics.
