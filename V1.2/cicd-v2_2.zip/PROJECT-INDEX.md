# CI/CD Pipeline v2.0 - Project Index

**Version:** 2.0
**Created:** 2025-12-26
**Source:** github.com/GadOfir/ai-knowledge-control/V1.2

---

## Quick Start

```
1. Tell Claude: "@cicd" or "start pipeline"
2. Provide README source (GitHub URL or local file)
3. Confirm settings
4. Provide improvement requests
5. Approve proposal
6. Review test results
7. Approve upgrade
```

---

## File Structure

```
CICD-v2/
├── PROJECT-INDEX.md          # This file - master index
├── CICD-PIPELINE.md          # Main pipeline skill (Phases 0-4)
├── TEST-DEFINITIONS.md       # All 50 test specifications
├── PRE-FLIGHT.md             # Environment validation checks
├── SLOP-PATTERNS.md          # Wording quality rules
│
└── test-vault/               # Test environment
    ├── README.md             # Populated test README (10 CIDs)
    ├── data/
    │   ├── DATA-001.md       # D01: Server config
    │   ├── DATA-002.md       # D02: API endpoints
    │   └── DATA-EMPTY.md     # D03: Empty file (edge case)
    ├── skills/
    │   ├── SKILL-001.md      # S01: Valid skill
    │   └── SKILL-BROKEN.md   # S02: Malformed (edge case)
    ├── projects/
    │   └── PROJECT-001/
    │       ├── PROJECT-INDEX.md  # P01: Project index
    │       ├── artifact-1.md     # Local file (no registry)
    │       └── logs/
    │           └── log-001.md    # Nested local file
    ├── edge-cases/
    │   ├── unicode-שלום.md   # E01: Unicode filename
    │   ├── spaces in name.md # E02: Spaces in filename
    │   └── CAPS.MD           # E03: Uppercase extension
    ├── _update/              # Staging area
    └── _trash/               # Cleanup area
```

---

## Pipeline Summary

| Phase | Name | Gate | Output |
|-------|------|------|--------|
| 0 | Onboarding | USER | Source + settings confirmed |
| 1 | Pre-flight | AUTO | 7/7 checks passed |
| 2 | Analyze | USER | Proposal approved |
| 3 | Implement & Test | AUTO | 50/50 tests passed |
| 4 | Report & Upgrade | USER | Version upgraded |

---

## Test Summary

| Suite | Count | Focus |
|-------|-------|-------|
| A: Routing | 10 | CID lookup, path resolution |
| B: Staging | 8 | _update mechanism |
| C: Registry | 6 | Section 2 operations |
| D: Expansion | 5 | Section 5 rules |
| E: Self-Healing | 4 | Section 6 maintenance |
| F: Edge Cases | 6 | Unusual inputs |
| NEG: Negative | 4 | Must-fail enforcement |
| BOUND: Boundary | 4 | Limits and performance |
| RECOV: Recovery | 3 | Error handling |
| **TOTAL** | **50** | |

---

## Metrics Tracked

### Performance
- Pipeline execution time
- Average test time
- File operations count

### Wording
- Total lines (before/after)
- Filler phrases removed
- Duplicate content eliminated
- Slop score percentage

### AI Compliance
- Routing accuracy (found correct CID?)
- Staging compliance (used _update?)
- Rule enforcement (blocked violations?)

---

## Commands

| Command | Action |
|---------|--------|
| `@cicd` | Start pipeline |
| `@cicd status` | Show progress |
| `@cicd abort` | Cancel and cleanup |

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0 | 2025-12-26 | Simplified from 12 skills to 1, added pre-flight, 50 tests |
| 1.1 | 2025-12-25 | Original complex pipeline (deprecated) |

---

## GitHub Source

**Primary:** `https://github.com/GadOfir/ai-knowledge-control/blob/main/V1.2/README.MD`

**Raw:** `https://raw.githubusercontent.com/GadOfir/ai-knowledge-control/main/V1.2/README.MD`
