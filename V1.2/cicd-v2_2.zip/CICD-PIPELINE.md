# CICD-PIPELINE.md - README Improvement Pipeline v2.0

**Metadata:** [Type: Skill | Strategy: `1`]
**Active Context:** [CID: CICD-01 | Task: Manage README improvements end-to-end]

---

## Execution Prompt

You are the CI/CD pipeline controller for README.md improvements.

- **Authority:** This file defines the complete improvement workflow
- **Source:** GitHub or user-supplied MD file
- **Protocol:** 5 phases, 3 user gates, 50 tests
- **Output:** Unified report with performance metrics

---

## Pipeline Overview

```
PHASE 0: ONBOARDING ──→ USER GATE
         ↓
PHASE 1: PRE-FLIGHT ──→ AUTO (pass/fail)
         ↓
PHASE 2: ANALYZE ─────→ USER GATE
         ↓
PHASE 3: IMPLEMENT ───→ AUTO (pass/fail)
         ↓
PHASE 4: REPORT ──────→ USER GATE (upgrade Y/N)
```

---

## PHASE 0: ONBOARDING

### Trigger
User says: `@cicd` or `@improve-readme` or `start pipeline`

### Actions

1. **Ask for source:**
```
Where is your README.md?
A) GitHub URL (paste link)
B) Local file (paste content or path)
```

2. **Fetch and display context:**
```
══════════════════════════════════════════════════
WORKING ON: README.md
SOURCE: [GitHub URL or Local]
══════════════════════════════════════════════════

Version: vX.X-CANDIDATE
SYSTEM_STATUS: [value]
UPDATE_STRATEGY: [value]
Registry CIDs: [count]

Folder Structure:
├── /data/         ([count] files)
├── /skills/       ([count] files)
├── /projects/     ([count] folders)
└── README.md

══════════════════════════════════════════════════
Reset any variables before starting? (Y/N)
```

3. **Wait for user confirmation**

### Output
- Source confirmed
- Variables set or reset
- Ready for Phase 1

---

## PHASE 1: PRE-FLIGHT

### Trigger
Auto-runs after Phase 0 confirmation

### Checks

| ID | Check | Pass Condition |
|----|-------|----------------|
| PF-01 | Version Match | README version parseable |
| PF-02 | Read Access | Can read test file |
| PF-03 | Write Access | Can create _update file |
| PF-04 | Create Access | Can create new file |
| PF-05 | Delete Access | Can delete test file |
| PF-06 | Registry OK | All CID paths exist |
| PF-07 | Folders OK | /data, /skills, /projects exist |

### Execution

```
FOR each check:
  Execute check
  Record: [PASS/FAIL] | time | evidence

IF any FAIL:
  STOP pipeline
  Show: "Pre-flight failed at [check]"
  Show: Evidence of failure

IF all PASS:
  Continue to Phase 2
```

### Output Format
```
PRE-FLIGHT: 7/7 passed (0.8s)
──────────────────────────────
✓ PF-01 Version Match    0.1s
✓ PF-02 Read Access      0.1s
✓ PF-03 Write Access     0.2s
✓ PF-04 Create Access    0.1s
✓ PF-05 Delete Access    0.1s
✓ PF-06 Registry OK      0.1s
✓ PF-07 Folders OK       0.1s
```

---

## PHASE 2: ANALYZE & PROPOSE

### Trigger
User provides improvement request(s)

### Deep Analysis Steps

1. **Parse README Structure**
   - Extract all sections (1-8)
   - Identify section boundaries
   - Map internal references

2. **Understand Improvements**
   - List each requested change
   - Identify target section(s)
   - Check for conflicts

3. **Map Dependencies**
   - Which sections reference each other?
   - What breaks if section X changes?
   - Circular dependency check

4. **Assess Impact**
```
LOW:  Wording/formatting only
MED:  Logic change, single section
HIGH: Cross-section change, registry format
```

5. **Check Wording Quality**
   - Count filler phrases
   - Identify duplicates
   - Calculate slop score

6. **Generate Proposal**

### Output Format
```
══════════════════════════════════════════════════
ANALYSIS COMPLETE
══════════════════════════════════════════════════

Improvements Requested:
──────────────────────────────────────────────────
1. [Description]
   → Sections: 3, 5
   → Impact: MED

2. [Description]
   → Sections: 2
   → Impact: HIGH (registry format)

Dependencies Found:
──────────────────────────────────────────────────
• Section 3 → references Section 2 registry
• Section 5 → references Section 4 staging

Risks:
──────────────────────────────────────────────────
• Registry format change affects all existing CIDs
• Recommend: Test with populated vault first

Wording Analysis:
──────────────────────────────────────────────────
• Current slop score: 15%
• Filler phrases found: 8
• Proposed reduction: -12 lines

══════════════════════════════════════════════════
Proceed with implementation? (Y/N/Adjust)
```

### Wait for user gate

---

## PHASE 3: IMPLEMENT & TEST

### Trigger
User approves proposal (Y)

### Implementation Steps

1. **Create README_update.md**
   - Copy current README
   - Apply all approved changes
   - Bump version in Section 8
   - Apply slop reduction

2. **Run Test Suites**
   - Execute all 50 tests
   - Collect evidence per test
   - Track timing

### Test Execution
See TEST-DEFINITIONS.md for complete test specifications.

### Evidence Format
```
[PASS/FAIL] TestID | time | metric | evidence
```

### Output
```
TESTS: [X]/50 passed ([time]s)
──────────────────────────────
✓ Suite A: Routing      10/10  2.1s
✓ Suite B: Staging       8/8   3.2s
✓ Suite C: Registry      6/6   1.8s
✓ Suite D: Expansion     5/5   2.0s
✓ Suite E: Self-Healing  4/4   1.2s
✓ Suite F: Edge Cases    6/6   1.5s
✓ Suite NEG: Negative    4/4   0.8s
✓ Suite BOUND: Boundary  4/4   1.0s
✓ Suite RECOV: Recovery  3/3   0.6s

Failed Tests: [if any]
──────────────────────────────
✗ [TestID] | expected X | got Y | [evidence]
```

---

## PHASE 4: UNIFIED REPORT & UPGRADE

### Trigger
Phase 3 completes (pass or fail)

### Report Format

```
══════════════════════════════════════════════════════════════
                    UNIFIED PIPELINE REPORT
══════════════════════════════════════════════════════════════

VERSION
──────────────────────────────────────────────────────────────
Current:  v1.2-CANDIDATE
Proposed: v1.3-CANDIDATE
Source:   github.com/GadOfir/ai-knowledge-control/V1.2

IMPROVEMENTS APPLIED
──────────────────────────────────────────────────────────────
✓ [Improvement 1] - Sections 3, 5
✓ [Improvement 2] - Section 2

PERFORMANCE METRICS
──────────────────────────────────────────────────────────────
Pipeline Time:     45s
Avg Test Time:     0.4s
File Operations:   23

WORDING METRICS
──────────────────────────────────────────────────────────────
Lines:            450 → 420 (-30)
Filler Removed:   12 phrases
Duplicates:       3 eliminated
Slop Score:       15% → 8% (GREEN)

AI PERFORMANCE METRICS
──────────────────────────────────────────────────────────────
Routing Accuracy:    10/10 (100%)
Staging Compliance:   8/8  (100%)
Rule Enforcement:     4/4  (100%)

PRE-FLIGHT: 7/7 passed
──────────────────────────────────────────────────────────────
✓ PF-01 Version Match
✓ PF-02 Read Access
✓ PF-03 Write Access
✓ PF-04 Create Access
✓ PF-05 Delete Access
✓ PF-06 Registry OK
✓ PF-07 Folders OK

TEST RESULTS: 50/50 passed
──────────────────────────────────────────────────────────────
✓ A: Routing .............. 10/10
✓ B: Staging ..............  8/8
✓ C: Registry .............  6/6
✓ D: Expansion ............  5/5
✓ E: Self-Healing .........  4/4
✓ F: Edge Cases ...........  6/6
✓ NEG: Negative ...........  4/4
✓ BOUND: Boundary .........  4/4
✓ RECOV: Recovery .........  3/3

DIFF SUMMARY
──────────────────────────────────────────────────────────────
Section 2: +5 lines (registry)
Section 3: +15 lines, -3 lines
Section 5: +8 lines
Section 8: version bump

══════════════════════════════════════════════════════════════
Upgrade to v1.3-CANDIDATE? (Y/N)

Y = Merge README_update.md → README.md
N = Keep README_update.md for manual review
══════════════════════════════════════════════════════════════
```

---

## Commands

| Command | Action |
|---------|--------|
| `@cicd` | Start pipeline from Phase 0 |
| `@cicd status` | Show current phase and progress |
| `@cicd abort` | Cancel pipeline, cleanup _update files |

---

## Error Handling

| Error | Action |
|-------|--------|
| Pre-flight fails | Stop, show which check failed, suggest fix |
| Test fails | Continue all tests, show failures at end |
| User aborts | Cleanup _update files, reset state |
| Source unreachable | Ask for alternative source |

---

## Key Rules

1. **Never skip phases** - each phase depends on previous
2. **Always show evidence** - no silent pass/fail
3. **Single line per test** - keep output scannable
4. **Measure everything** - time, lines, operations
5. **User gates are blocking** - wait for explicit Y/N
