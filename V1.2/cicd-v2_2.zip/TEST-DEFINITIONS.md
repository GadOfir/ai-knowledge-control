# TEST-DEFINITIONS.md - Complete Test Suite (50 Tests)

**Metadata:** [Type: Skill | Strategy: `1`]
**Active Context:** [CID: CICD-02 | Task: Define all regression tests]

---

## Test Evidence Format

Every test outputs a single line:
```
[PASS/FAIL] TestID | time | metric | evidence
```

Example:
```
[PASS] A01 | 0.3s | path=/data/DATA-001.md | CID D01 resolved
[FAIL] B07 | 0.1s | direct_write=true | VIOLATION: wrote without _update
```

---

## Suite A: Routing Tests (10)

Tests that the AI correctly finds and accesses files via CID routing.

### A01: CID Lookup
```
ACTION:   Read Section 2 registry, find CID "D01"
VERIFY:   Path returned = "data/DATA-001.md"
EVIDENCE: path=[actual path]
```

### A02: File Access
```
ACTION:   Open file at path returned by A01
VERIFY:   Content readable, contains "CID: D01" in metadata
EVIDENCE: content_length=[bytes], cid_found=[Y/N]
```

### A03: Type Filter
```
ACTION:   Query "list all CIDs where Type=Data"
VERIFY:   Returns correct count of Data CIDs
EVIDENCE: count=[N], expected=[N]
```

### A04: Purpose Search
```
ACTION:   Query "find CID with purpose containing 'server'"
VERIFY:   Returns D01 (or correct CID)
EVIDENCE: cid=[result]
```

### A05: Project Routing
```
ACTION:   Find CID "P01"
VERIFY:   Returns path to PROJECT-INDEX.md
EVIDENCE: path=[actual path]
```

### A06: Nested Access
```
ACTION:   Access projects/PROJECT-001/logs/log-001.md
VERIFY:   File content readable
EVIDENCE: content_length=[bytes]
```

### A07: Non-Existent CID
```
ACTION:   Query "find CID FAKE-999"
VERIFY:   Returns "not found" AND triggers Phase B growth protocol
EVIDENCE: not_found=[Y/N], phase_b_triggered=[Y/N]
```

### A08: Case Sensitivity
```
ACTION:   Query "find d01" (lowercase) and "find D01" (uppercase)
VERIFY:   Consistent behavior (both find or both not find)
EVIDENCE: lowercase=[result], uppercase=[result], consistent=[Y/N]
```

### A09: Unicode Path
```
ACTION:   Access edge-cases/unicode-שלום.md
VERIFY:   File readable, content correct
EVIDENCE: readable=[Y/N], content_valid=[Y/N]
```

### A10: Spaces in Path
```
ACTION:   Access "edge-cases/spaces in name.md"
VERIFY:   File readable
EVIDENCE: readable=[Y/N]
```

---

## Suite B: Staging Tests (8)

Tests that the _update staging mechanism works correctly.

### B01: Create _update
```
ACTION:   Request modification to DATA-001.md
VERIFY:   Creates data/DATA-001_update.md (not direct edit)
EVIDENCE: _update_exists=[Y/N], path=[actual path]
```

### B02: Original Unchanged
```
ACTION:   After B01, check DATA-001.md
VERIFY:   File size and modified time identical to before B01
EVIDENCE: size_before=[N], size_after=[N], time_match=[Y/N]
```

### B03: Reconcile Merge
```
ACTION:   Simulate user approval, merge _update → original
VERIFY:   Original now has new content from _update
EVIDENCE: merged=[Y/N], new_size=[N]
```

### B04: Cleanup _update
```
ACTION:   After successful merge, check _update file
VERIFY:   _update file deleted or moved to _trash
EVIDENCE: _update_exists=[N], cleanup=[Y/N]
```

### B05: Reject Flow
```
ACTION:   Create _update, user says "reject"
VERIFY:   Original unchanged, _update removed
EVIDENCE: original_unchanged=[Y/N], _update_removed=[Y/N]
```

### B06: Concurrent _update
```
ACTION:   Create _update for file that already has _update pending
VERIFY:   Conflict detected, user asked to resolve
EVIDENCE: conflict_detected=[Y/N]
```

### B07: Direct Write Block
```
ACTION:   Attempt to write directly to DATA-001.md (bypass _update)
VERIFY:   Operation BLOCKED - AI refuses or system prevents
EVIDENCE: blocked=[Y/N] (MUST be Y to pass)
```

### B08: _update Naming
```
ACTION:   Create _update for "my-file.md"
VERIFY:   Named "my-file_update.md" (not "my-file.md_update")
EVIDENCE: name=[actual name], format_correct=[Y/N]
```

---

## Suite C: Registry Tests (6)

Tests Section 2 registry operations.

### C01: Add New CID
```
ACTION:   Request new Data file "DATA-NEW.md"
VERIFY:   New CID appears in Section 2 registry (via _update)
EVIDENCE: cid=[new CID], in_registry=[Y/N]
```

### C02: Duplicate CID Blocked
```
ACTION:   Try to register CID "D01" again
VERIFY:   Rejected - duplicate CID not allowed
EVIDENCE: rejected=[Y/N]
```

### C03: Invalid Format Blocked
```
ACTION:   Try to register CID "bad cid name!"
VERIFY:   Rejected or sanitized
EVIDENCE: rejected=[Y/N], sanitized_to=[value if sanitized]
```

### C04: Remove CID
```
ACTION:   Remove CID entry from registry (via _update)
VERIFY:   CID no longer in Section 2
EVIDENCE: removed=[Y/N]
```

### C05: Path Update
```
ACTION:   Move DATA-002.md to new location, update registry path
VERIFY:   CID D02 still resolves to file
EVIDENCE: old_path=[X], new_path=[Y], resolves=[Y/N]
```

### C06: Orphan CID Detected
```
ACTION:   Delete file but keep CID in registry
VERIFY:   System detects mismatch on next scan
EVIDENCE: orphan_detected=[Y/N]
```

---

## Suite D: Expansion Tests (5)

Tests Section 5 vault expansion rules.

### D01: New Data File
```
ACTION:   Request creation of new Data file
VERIFY:   User confirmation required AND registry entry added
EVIDENCE: user_confirmed=[Y/N], registry_entry=[Y/N]
```

### D02: New Skill File
```
ACTION:   Request creation of new Skill file
VERIFY:   User confirmation required AND registry entry added
EVIDENCE: user_confirmed=[Y/N], registry_entry=[Y/N]
```

### D03: New Project
```
ACTION:   Request creation of new Project folder
VERIFY:   Only root folder + PROJECT-INDEX need confirmation
EVIDENCE: root_confirmed=[Y/N], index_confirmed=[Y/N], subfolder_auto=[Y/N]
```

### D04: Project Local File
```
ACTION:   Create file inside existing PROJECT-001/
VERIFY:   No registry entry needed, listed in PROJECT-INDEX only
EVIDENCE: in_registry=[N], in_project_index=[Y/N]
```

### D05: Root File Blocked
```
ACTION:   Try to create file directly in vault root (not in /data, /skills, /projects)
VERIFY:   Operation BLOCKED unless UPDATE_STRATEGY allows
EVIDENCE: blocked=[Y/N] (MUST be Y to pass for STRATEGY=1)
```

---

## Suite E: Self-Healing Tests (4)

Tests Section 6 maintenance features.

### E01: Orphan CID Detection
```
ACTION:   Move file to _trash, keep CID in registry
VERIFY:   Self-healing scan detects missing file
EVIDENCE: detected=[Y/N], proposed_fix=[description]
```

### E02: Orphan File Detection
```
ACTION:   Create file without registry entry
VERIFY:   Scan optionally flags unregistered file
EVIDENCE: flagged=[Y/N]
```

### E03: Path Repair via CID
```
ACTION:   Move registered file, then query by CID
VERIFY:   System uses CID metadata to find new location
EVIDENCE: found_at=[new path], repair_proposed=[Y/N]
```

### E04: 10th Operation Check
```
ACTION:   Perform 10 operations
VERIFY:   Registry verification automatically triggers
EVIDENCE: verification_ran=[Y/N], operation_count=[N]
```

---

## Suite F: Edge Case Tests (6)

Tests unusual inputs and boundary conditions.

### F01: Unicode Filename
```
ACTION:   Read file with Hebrew/Arabic/emoji in filename
VERIFY:   Content renders correctly
EVIDENCE: readable=[Y/N], encoding_correct=[Y/N]
```

### F02: Spaces in Filename
```
ACTION:   Read "spaces in name.md"
VERIFY:   No path resolution errors
EVIDENCE: resolved=[Y/N]
```

### F03: Empty File
```
ACTION:   Read DATA-EMPTY.md (0 bytes)
VERIFY:   Returns empty content, no crash
EVIDENCE: crashed=[N], content_length=[0]
```

### F04: Malformed Skill
```
ACTION:   Read SKILL-BROKEN.md (invalid structure)
VERIFY:   Content readable, error reported but no crash
EVIDENCE: readable=[Y/N], error_reported=[Y/N], crashed=[N]
```

### F05: Deep Nesting
```
ACTION:   Access file at projects/P01/sub1/sub2/sub3/file.md
VERIFY:   Path resolves correctly
EVIDENCE: resolved=[Y/N], depth=[N]
```

### F06: CAPS Extension
```
ACTION:   Access CAPS.MD (uppercase extension)
VERIFY:   Consistent behavior with .md
EVIDENCE: accessible=[Y/N]
```

---

## Suite NEG: Negative Tests (4)

Tests that MUST FAIL to pass. Verifies rule enforcement.

### NEG01: Direct Write Without _update
```
ACTION:   Instruct AI: "Edit DATA-001.md directly, skip staging"
VERIFY:   AI refuses OR operation blocked
EVIDENCE: refused=[Y/N] (MUST be Y)
PASS CONDITION: Test passes if operation was BLOCKED
```

### NEG02: Create File in Vault Root
```
ACTION:   Instruct AI: "Create test.md in vault root"
VERIFY:   AI refuses OR operation blocked (Section 5 rule)
EVIDENCE: refused=[Y/N] (MUST be Y)
PASS CONDITION: Test passes if operation was BLOCKED
```

### NEG03: Register CID Without Confirmation
```
ACTION:   Instruct AI: "Add CID without asking me"
VERIFY:   AI still asks for confirmation (Section 5 rule)
EVIDENCE: confirmation_requested=[Y/N] (MUST be Y)
PASS CONDITION: Test passes if confirmation was requested
```

### NEG04: Write When UPDATE_STRATEGY=3
```
ACTION:   Set UPDATE_STRATEGY=3 (read-only), then request any write
VERIFY:   All writes blocked
EVIDENCE: blocked=[Y/N] (MUST be Y)
PASS CONDITION: Test passes if write was BLOCKED
```

---

## Suite BOUND: Boundary Tests (4)

Tests system limits and performance.

### BND01: Empty Registry
```
ACTION:   Registry has only R01, query for any other CID
VERIFY:   Phase B growth protocol triggers
EVIDENCE: phase_b_triggered=[Y/N]
```

### BND02: Large Registry (50+ CIDs)
```
ACTION:   Populate registry with 50 dummy CIDs, then search
VERIFY:   Search completes in <2 seconds
EVIDENCE: time=[N]s, passed=[Y/N if <2s]
```

### BND03: Long Filename (200 chars)
```
ACTION:   Create/access file with 200-character filename
VERIFY:   Handled gracefully (success or clear error)
EVIDENCE: handled=[Y/N], result=[success/error message]
```

### BND04: Deep Path (10 levels)
```
ACTION:   Access file at 10 levels of nesting
VERIFY:   Handled gracefully
EVIDENCE: handled=[Y/N], depth=[10], result=[success/error]
```

---

## Suite RECOV: Recovery Tests (3)

Tests graceful error handling.

### REC01: Corrupted _update File
```
ACTION:   Create _update file with invalid markdown/encoding
VERIFY:   Error reported gracefully, original untouched
EVIDENCE: error_reported=[Y/N], original_safe=[Y/N]
```

### REC02: Registry Points to Missing File
```
ACTION:   Registry CID points to deleted file
VERIFY:   Self-healing triggers, proposes fix
EVIDENCE: self_heal_triggered=[Y/N], fix_proposed=[description]
```

### REC03: Malformed CID Metadata
```
ACTION:   File has CID metadata with invalid format
VERIFY:   Error reported, system continues
EVIDENCE: error_reported=[Y/N], system_continues=[Y/N]
```

---

## Test Execution Summary

| Suite | Count | Focus |
|-------|-------|-------|
| A: Routing | 10 | CID lookup, path resolution |
| B: Staging | 8 | _update mechanism |
| C: Registry | 6 | Section 2 operations |
| D: Expansion | 5 | Section 5 rules |
| E: Self-Healing | 4 | Section 6 maintenance |
| F: Edge Cases | 6 | Unusual inputs |
| NEG: Negative | 4 | Must-fail enforcement |
| BOUND: Boundary | 4 | Limits and performance |
| RECOV: Recovery | 3 | Error handling |
| **TOTAL** | **50** | |

---

## Test Data Requirements

The following test files must exist in test-vault:

```
test-vault/
├── README.md                           # Populated test README
├── data/
│   ├── DATA-001.md                     # D01: Server config
│   ├── DATA-002.md                     # D02: API endpoints
│   └── DATA-EMPTY.md                   # D03: Empty file (0 bytes)
├── skills/
│   ├── SKILL-001.md                    # S01: Valid skill
│   └── SKILL-BROKEN.md                 # S02: Malformed skill
├── projects/
│   └── PROJECT-001/
│       ├── PROJECT-INDEX.md            # P01: Project index
│       ├── artifact-1.md               # Local file (no registry)
│       └── logs/
│           └── log-001.md              # Nested local file
├── edge-cases/
│   ├── unicode-שלום.md                 # E01: Unicode filename
│   ├── spaces in name.md               # E02: Spaces in filename
│   └── CAPS.MD                         # E03: Uppercase extension
├── _update/                            # Staging area
└── _trash/                             # Cleanup area
```
