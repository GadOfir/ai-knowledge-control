# PRE-FLIGHT.md - Environment Validation Checks

**Metadata:** [Type: Skill | Strategy: `1`]
**Active Context:** [CID: CICD-03 | Task: Validate environment before testing]

---

## Execution Prompt

Run these checks before any pipeline operation.
ALL checks must pass to proceed.

---

## Pre-Flight Checks (7 Total)

### PF-01: Version Match

**Purpose:** Ensure we're working on the expected README version

**Action:**
```
1. Read first line of README.md
2. Extract version from Section 8 (SYSTEM_STATUS line)
3. Compare to expected version
```

**Pass Condition:** Version string found and parseable

**Evidence:** `version=[extracted version]`

---

### PF-02: Read Access

**Purpose:** Verify we can read files from the vault

**Action:**
```
1. Attempt to read data/DATA-001.md
2. Verify content is returned
3. Check content length > 0
```

**Pass Condition:** File content returned successfully

**Evidence:** `read=Y, bytes=[N]`

---

### PF-03: Write Access

**Purpose:** Verify we can create _update files

**Action:**
```
1. Create _update/_preflight_test.md with test content
2. Verify file exists
3. Read back content to confirm
```

**Pass Condition:** File created and readable

**Evidence:** `write=Y, path=_update/_preflight_test.md`

---

### PF-04: Create Access

**Purpose:** Verify we can create new files in valid locations

**Action:**
```
1. Create _update/_preflight_create.md
2. Verify file exists
```

**Pass Condition:** File created

**Evidence:** `create=Y`

---

### PF-05: Delete Access

**Purpose:** Verify we can delete test files

**Action:**
```
1. Delete _update/_preflight_test.md (from PF-03)
2. Delete _update/_preflight_create.md (from PF-04)
3. Verify files no longer exist
```

**Pass Condition:** Files deleted

**Evidence:** `delete=Y, cleaned=[N] files`

---

### PF-06: Registry Integrity

**Purpose:** Verify all CID paths in registry point to real files

**Action:**
```
1. Parse Section 2 registry table
2. For each CID, check if Authoritative Path exists
3. Report any missing files
```

**Pass Condition:** All paths exist

**Evidence:** `registry_ok=Y, cids_checked=[N], missing=[list or none]`

---

### PF-07: Folder Structure

**Purpose:** Verify required folders exist

**Action:**
```
1. Check /data/ exists
2. Check /skills/ exists
3. Check /projects/ exists
4. Check /_update/ exists
```

**Pass Condition:** All folders exist

**Evidence:** `folders_ok=Y, data=Y, skills=Y, projects=Y, _update=Y`

---

## Execution Script

```
START pre-flight
  time_start = now()
  
  FOR check IN [PF-01..PF-07]:
    check_start = now()
    result = execute(check)
    check_time = now() - check_start
    
    LOG: [PASS/FAIL] {check.id} | {check_time}s | {result.evidence}
    
    IF result == FAIL:
      STOP pipeline
      SHOW: "Pre-flight failed at {check.id}"
      SHOW: {result.evidence}
      EXIT
  
  total_time = now() - time_start
  LOG: "PRE-FLIGHT: 7/7 passed ({total_time}s)"
  CONTINUE to Phase 2
```

---

## Output Format

```
PRE-FLIGHT: 7/7 passed (0.8s)
──────────────────────────────
✓ PF-01 Version Match    0.1s  version=v1.2-TEST
✓ PF-02 Read Access      0.1s  bytes=423
✓ PF-03 Write Access     0.2s  path=_update/_preflight_test.md
✓ PF-04 Create Access    0.1s  created=Y
✓ PF-05 Delete Access    0.1s  cleaned=2 files
✓ PF-06 Registry OK      0.1s  cids_checked=10, missing=none
✓ PF-07 Folders OK       0.1s  all present
```

---

## Failure Examples

```
PRE-FLIGHT: 5/7 passed - FAILED
──────────────────────────────
✓ PF-01 Version Match    0.1s
✓ PF-02 Read Access      0.1s
✓ PF-03 Write Access     0.2s
✓ PF-04 Create Access    0.1s
✓ PF-05 Delete Access    0.1s
✗ PF-06 Registry OK      0.1s  MISSING: data/DATA-003.md
─ PF-07 Folders OK       SKIP  (stopped at PF-06)

PIPELINE STOPPED: Fix registry before continuing
```

---

## Recovery Actions

| Failed Check | Suggested Fix |
|--------------|---------------|
| PF-01 | Verify README source URL, re-fetch if needed |
| PF-02 | Check file permissions, verify vault path |
| PF-03 | Create _update folder, check write permissions |
| PF-04 | Check folder permissions |
| PF-05 | Check delete permissions |
| PF-06 | Run self-healing to fix registry, or remove orphan CIDs |
| PF-07 | Create missing folders |
