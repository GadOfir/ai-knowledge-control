# SKILL-001 - Deployment Automation

**Metadata:** [Type: Skill | Strategy: `1`]
**Active Context:** [CID: S01 | Task: Automated deployment procedures]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING ONLY. Do not write to original files.
- **Task:** Execute deployment procedures
- **Expected Output:** Staged deployment logs for user review

---

## Purpose

Automate deployment procedures for test environments.

---

## Decision Chains

```
IF deployment_target == "staging":
  → Run pre-flight checks
  → Execute deployment script
  → Verify health endpoints
  → Log results to PROJECT-001

IF deployment_target == "production":
  → REQUIRE user confirmation
  → Run extended validation
  → Execute with rollback ready
```

---

## Common Commands

```bash
# Check deployment status
curl -s http://localhost:8080/health

# Restart service
systemctl restart app-service

# View logs
journalctl -u app-service -f
```

---

## Common Issues

| Issue | Solution |
|-------|----------|
| Health check fails | Verify port 8080 is open |
| Service won't start | Check config syntax |

---

## Key Learnings

- Always verify health before declaring success
- Keep rollback scripts ready
- Log everything

---

## Notes

Valid skill file for routing tests (Suite A).
