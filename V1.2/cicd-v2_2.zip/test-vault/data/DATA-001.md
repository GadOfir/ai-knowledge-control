# DATA-001 - Server Configuration Reference

**Authority:** README.md
**Type:** Data (Reference only)
**Update Strategy:** Inherited from README Section 1

Metadata: [CID: D01 | Category: Infrastructure]

---

## Purpose

Reference data for server configuration used in deployment and testing.

---

## Content

```yaml
server:
  name: prod-server-01
  ip: 192.168.1.100
  port: 8080
  environment: production

database:
  host: db.internal
  port: 5432
  name: app_production

features:
  - logging: enabled
  - metrics: enabled
  - cache: redis
```

---

## Notes

Test data for routing verification (Suite A tests).
