# DATA-002 - API Endpoints Reference

**Authority:** README.md
**Type:** Data (Reference only)
**Update Strategy:** Inherited from README Section 1

Metadata: [CID: D02 | Category: API]

---

## Purpose

Reference data for API endpoints used in integration tests.

---

## Content

```yaml
endpoints:
  - name: users
    path: /api/v1/users
    methods: [GET, POST, PUT, DELETE]
    
  - name: auth
    path: /api/v1/auth
    methods: [POST]
    
  - name: health
    path: /api/v1/health
    methods: [GET]
```

---

## Notes

Test data for registry operations (Suite C tests).
