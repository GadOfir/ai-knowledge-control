# README.md - Test Vault for CI/CD Regression Testing

## System Onboarding: [██████████] 100%

> Status: TEST ENVIRONMENT | Purpose: CI/CD Pipeline Regression Testing

---

## System Overview

Test vault with populated CIDs for executing 50 regression tests.

---

## Execution Prompt (Runtime Authority)

- **Authority:** `README.md` is the **Single Source of Truth**
- **Safety:** The AI is **FORBIDDEN from writing to original files directly**
- **Protocol:** All changes **MUST** be staged in `_update` files

---

## 1. Global Update Strategy & Authority

**UPDATE_STRATEGY =** `1`

| Value | Behavior |
|-------|----------|
| **1 - Build** | Stage ALL data in `_update` files for user review |
| **2 - Proposal** | Ask before creating `_update` file |
| **3 - Read-Only** | No writes allowed |

---

## 2. Master Vault Registry (Index & Paths)

| CID | Name | Type | Capability / Purpose | Authoritative Path |
|-----|------|------|---------------------|-------------------|
| R01 | README | Skill | System Authority & Routing | `README.md` |
| D01 | DATA-001 | Data | Server configuration reference | `data/DATA-001.md` |
| D02 | DATA-002 | Data | API endpoints reference | `data/DATA-002.md` |
| D03 | DATA-EMPTY | Data | Empty file edge case | `data/DATA-EMPTY.md` |
| S01 | SKILL-001 | Skill | Deployment automation | `skills/SKILL-001.md` |
| S02 | SKILL-BROKEN | Skill | Malformed skill edge case | `skills/SKILL-BROKEN.md` |
| P01 | PROJECT-001 | Project | Test project with artifacts | `projects/PROJECT-001/PROJECT-INDEX.md` |
| E01 | UNICODE | Data | Unicode filename test | `edge-cases/unicode-שלום.md` |
| E02 | SPACES | Data | Spaces in filename test | `edge-cases/spaces in name.md` |
| E03 | CAPS | Data | Case sensitivity test | `edge-cases/CAPS.MD` |

---

## 3. Unified Execution Brain (Routing & Growth)

### Phase A: Routing (Decision Chain)

1. **Consult R01:** Establish global rules
2. **Locate Context:** Search Section 2 Registry by Purpose/Capability
3. **Execute:** Open file, follow Execution Prompt

### Phase B: Growth (Pre-Creation Protocol)

1. **Inquiry:** Ask user for scope
2. **Missing Info:** Identify gaps
3. **Registry Proposal:** Propose CID, Type, Path

---

## 4. Shadow Staging & Reconciliation

- **Staging:** Create `filename_update.md` for ANY change
- **No Direct Writing:** Never modify original without staging
- **Reconciliation:** Compare → Propose → Apply after approval
- **Cleanup:** Delete `_update` after successful merge

---

## 5. Vault Expansion & Autonomy Policy

- **Data & Skill Files:** User confirmation + Registry entry required
- **Project Autonomy:** Only root folder + index need confirmation
- **Local Freedom:** Inside project, create files without registry

**Folder Structure Rules:**
- Vault root: Only README.md allowed
- Data CIDs: Must be in `/data/` folder
- Skill CIDs: Must be in `/skills/` folder
- Projects: Must be in `/projects/{{name}}/` folder

---

## 6. Maintenance & Self-Healing

- **Summarization:** Every 20 entries → propose summary
- **Self-Healing:** Every 10th operation → verify CIDs
- **Path Repair:** If file moved, use CID to find it

---

## 7. Vault File Template V1.4

[Standard template - see main README for details]

---

## 8. System Status

**SYSTEM_STATUS =** `ACTIVE`
**Version:** v1.2-TEST
**UPDATE_STRATEGY:** 1 (Build/Stage)

**Active Resources:**
- Projects: 1 (PROJECT-001)
- Skills: 2 (SKILL-001, SKILL-BROKEN)
- Data CIDs: 6 (D01-D03, E01-E03)
- Registry Size: 10 CIDs

---

### Files NOT in Registry (Project Autonomy)

| Path | Purpose |
|------|---------|
| `projects/PROJECT-001/artifact-1.md` | Project artifact |
| `projects/PROJECT-001/logs/log-001.md` | Project log |

---

### End of README
