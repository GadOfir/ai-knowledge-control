# Unicode Test - שלום

**Authority:** README.md
**Type:** Data (Reference only)
**Update Strategy:** Inherited

Metadata: [CID: E01 | Category: Edge Case]

---

## Purpose

Tests unicode handling in filenames and content.

---

## Content

Hebrew: שלום עולם
Arabic: مرحبا بالعالم
Chinese: 你好世界
Emoji: 🚀 🎉 ✅

---

## Notes

Edge case E01 for Suite F tests.
Filename contains Hebrew characters: unicode-שלום.md
