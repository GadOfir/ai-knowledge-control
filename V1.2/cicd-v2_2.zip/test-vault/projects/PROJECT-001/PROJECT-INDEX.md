# PROJECT-001 - Test Project

**Metadata:** [Type: Project | Strategy: `1`]
**Active Context:** [CID: P01 | Task: Test project autonomy rules]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING for index, local freedom for artifacts
- **Task:** Demonstrate project autonomy
- **Expected Output:** Artifacts without registry entries

---

## Purpose

Test project to verify Section 5 autonomy rules:
- Project root requires confirmation
- Index requires registry entry
- Internal files do NOT require registry entries
- Subfolders can be created freely

---

## Project File Registry

| File Path | Purpose | Created By |
|-----------|---------|------------|
| `PROJECT-INDEX.md` | This index file | Test Setup |
| `artifact-1.md` | Test artifact | Test Setup |
| `logs/log-001.md` | Test log entry | Test Setup |

---

## Notes

All files in this project should be accessible via P01 routing.
Tests: A05 (project routing), A06 (nested access), D04 (local file).
