# Artifact 1 - Test Artifact

**Parent Project:** PROJECT-001
**Registry Entry:** None (local file per Section 5)

---

## Content

This is a test artifact demonstrating project autonomy.

Files inside a project folder do not need registry entries.
They are tracked in the PROJECT-INDEX.md instead.

---

## Test Purpose

- Verifies D04: Project local file has no registry entry
- Verifies Section 5: Local freedom inside project folders
