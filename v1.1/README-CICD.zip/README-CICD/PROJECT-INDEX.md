# README-CICD Project Index

**Metadata:** [Type: Project | Strategy: `1` (Build/Stage)]  
**Active Context:** [CID: PRJ-README-CICD | Task: README Self-Improvement CICD Pipeline]

---

## Purpose

CI/CD pipeline for README.md self-improvement with safety validation, version control, and rollback.

---

## Project File Registry

| File Path | Purpose | Created By |
|-----------|---------|------------|
| `PROJECT-INDEX.md` | Project root index | User Request |
| `skills/S01-orchestrator.md` | Master CICD controller | AI Initiative |
| `skills/S02-constitutional-parser.md` | README structure analyzer | AI Initiative |
| `skills/S03-dependency-mapper.md` | Section dependency mapping | AI Initiative |
| `skills/S04-impact-analyzer.md` | Change impact prediction | AI Initiative |
| `skills/S05-improvement-generator.md` | Enhancement proposals | AI Initiative |
| `skills/S06-contract-validator.md` | Core contract enforcement | AI Initiative |
| `skills/S07-compatibility-tester.md` | Regression testing | AI Initiative |
| `skills/S08-sandbox-runner.md` | Isolated test environment | AI Initiative |
| `skills/S09-migration-planner.md` | Version transition planning | AI Initiative |
| `skills/S10-rollback-manager.md` | Emergency recovery | AI Initiative |
| `skills/S11-version-controller.md` | Version management | AI Initiative |
| `skills/S12-slop-reducer.md` | AI writing quality enforcer | AI Initiative |
| `test-vault/TEST-DATA-01.md` | Sample Data CID | AI Initiative |
| `test-vault/TEST-SKILL-01.md` | Sample Skill CID | AI Initiative |
| `test-vault/TEST-PROJECT-01/` | Sample Project | AI Initiative |
| `versions/v1.0/` | Production baseline | AI Initiative |
| `versions/v1.1-CANDIDATE/` | V1.1 candidate (immutable) | AI Initiative |
| `versions/.active-version` | Current version pointer | AI Initiative |

---

## Canonical Source

```
https://github.com/GadOfir/ai-knowledge-control/blob/main/V1/README.md
```

---

## Key Learnings

- Production state verification prevents dirty version testing
- Source confusion is critical failure mode
- S12 enforces writing quality across all skills