# SKILL-BROKEN – Malformed Skill for Edge Case Testing

**Metadata:** [Type: Skill | Strategy: INVALID_VALUE]  
**Active Context:** [CID: | Task: ]

---

## Execution Prompt

THIS SKILL IS INTENTIONALLY BROKEN FOR TESTING

- **Authority:** MISSING
- **Rules:** 
- **Task:** 
- **Expected Output:** 

---

## Purpose



---

## Decision Chains

```
IF broken:
  → This is not valid decision chain syntax
  MISSING ARROW
  NO CLOSING
```

---

## Common Commands

```
not a valid code block - missing language
```

---

RANDOM TEXT NOT IN A SECTION

| Broken | Table |
| Missing | Cell |
|---------|

## Notes

This file tests how the system handles malformed skills.