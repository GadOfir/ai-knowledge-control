# SKILL-001 – Deployment Automation

**Metadata:** [Type: Skill | Strategy: `1`]  
**Active Context:** [CID: S01 | Task: Automate deployment process]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING ONLY
- **Task:** Execute deployment steps
- **Expected Output:** Deployment log in _update file

---

## Purpose

Automates server deployment with validation steps.

---

## Decision Chains

```
IF deploy requested:
  1. Validate DATA-001 config exists
  2. Check server connectivity
  3. Execute deployment script
  4. Verify health endpoint
  5. Log result to _update file
```

---

## Common Commands

```bash
# Deploy command
./deploy.sh --env production --config DATA-001

# Health check
curl http://localhost:8080/api/health

# Rollback
./rollback.sh --version previous
```

---

## Common Issues

| Issue | Solution |
|-------|----------|
| Config not found | Verify D01 CID in registry |
| Connection timeout | Check firewall rules |
| Health check fails | Review deployment logs |

---

## Key Learnings

- Always validate config before deploy
- Health check is mandatory post-deploy