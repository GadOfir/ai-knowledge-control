# PROJECT-001 – Test Project

**Metadata:** [Type: Project | Strategy: `1`]  
**Active Context:** [CID: P01 | Task: Test project autonomy rules]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING for index, local freedom for artifacts
- **Task:** Demonstrate project autonomy
- **Expected Output:** Artifacts without registry entries

---

## Purpose

Test project to verify Section 5 autonomy rules:
- Project root requires confirmation
- Index requires registry entry
- Internal files do NOT require registry entries
- Subfolders can be created freely

---

## Project File Registry

| File Path | Purpose | Created By |
|-----------|---------|------------|
| `PROJECT-INDEX.md` | This index file | AI Initiative |
| `artifact-1.md` | Test artifact | AI Initiative |
| `logs/log-001.md` | Test log entry | AI Initiative |

---

## Notes

All files in this project should be accessible via P01 routing.