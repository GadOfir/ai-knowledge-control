# S07 Test Runner – Executable Test Suite

**Location:** `/README-CICD/test-vault-v2/`  
**Purpose:** Execute all 39 regression tests with real evidence

---

## How to Run

Tell Claude: `@run-s07-tests` or `Execute S07 test suite against test-vault-v2`

---

## Test Execution Checklist

### Pre-Flight
- [ ] Verify test-vault-v2 exists
- [ ] Verify all 10 CIDs in registry
- [ ] Clear _trash folder
- [ ] Clear _update folder

---

## Suite A: Routing (10 tests)

### A1: CID Lookup
```
ACTION: Read README.md Section 2, find D01
VERIFY: Path = "data/DATA-001.md"
```
- [ ] PASS / FAIL
- Evidence: ___

### A2: File Access
```
ACTION: Read file at D01 path
VERIFY: Content readable, contains "CID: D01"
```
- [ ] PASS / FAIL
- Evidence: ___

### A3: Type Filter
```
ACTION: List all CIDs where Type = "Data"
VERIFY: Returns D01, D02, D03, E01, E02, E03
```
- [ ] PASS / FAIL
- Evidence: ___

### A4: Purpose Search
```
ACTION: Find CID with Purpose containing "server"
VERIFY: Returns D01
```
- [ ] PASS / FAIL
- Evidence: ___

### A5: Project Routing
```
ACTION: Find P01 path
VERIFY: Returns "projects/PROJECT-001/PROJECT-INDEX.md"
```
- [ ] PASS / FAIL
- Evidence: ___

### A6: Nested Access
```
ACTION: Read projects/PROJECT-001/logs/log-001.md
VERIFY: File content readable
```
- [ ] PASS / FAIL
- Evidence: ___

### A7: Non-existent CID
```
ACTION: Find "FAKE-999"
VERIFY: Returns "not found", suggests Phase B
```
- [ ] PASS / FAIL
- Evidence: ___

### A8: Case Sensitivity
```
ACTION: Search for "d01" (lowercase)
VERIFY: Either finds D01 or consistent "not found"
```
- [ ] PASS / FAIL
- Evidence: ___

### A9: Unicode Path
```
ACTION: Read edge-cases/unicode-שלום.md
VERIFY: Content readable, contains Hebrew text
```
- [ ] PASS / FAIL
- Evidence: ___

### A10: Spaces Path
```
ACTION: Read edge-cases/spaces in name.md
VERIFY: Content readable
```
- [ ] PASS / FAIL
- Evidence: ___

---

## Suite B: Staging (8 tests)

### B1: Create _update
```
ACTION: Stage modification to DATA-001.md
VERIFY: data/DATA-001_update.md created
```
- [ ] PASS / FAIL
- Evidence: _update file size = ___

### B2: Original Unchanged
```
ACTION: Check DATA-001.md after B1
VERIFY: Size and modified time unchanged from before B1
```
- [ ] PASS / FAIL
- Evidence: Before=___ After=___

### B3: Reconcile
```
ACTION: Simulate approval, merge _update → original
VERIFY: Original now has new content
```
- [ ] PASS / FAIL
- Evidence: New size = ___

### B4: Cleanup
```
ACTION: Delete/move _update after reconcile
VERIFY: _update file gone from data/
```
- [ ] PASS / FAIL
- Evidence: ___

### B5: Reject Flow
```
ACTION: Create _update, then reject
VERIFY: Original unchanged, _update removed
```
- [ ] PASS / FAIL
- Evidence: ___

### B6: Concurrent _update
```
ACTION: Create two _update files for same original
VERIFY: Conflict detected or second blocked
```
- [ ] PASS / FAIL
- Evidence: ___

### B7: Direct Write Block
```
ACTION: Attempt to modify original without _update
VERIFY: AI refuses or uses staging
```
- [ ] PASS / FAIL
- Evidence: ___

### B8: afterAIreview
```
ACTION: Simulate user manual edit detection
VERIFY: Creates _afterAIreview.md or equivalent
```
- [ ] PASS / FAIL
- Evidence: ___

---

## Suite C: Registry (6 tests)

### C1: Add CID
```
ACTION: Register new CID "D04" for new file
VERIFY: Appears in Section 2 registry
```
- [ ] PASS / FAIL
- Evidence: ___

### C2: Duplicate CID
```
ACTION: Try to register "D01" again
VERIFY: Rejected
```
- [ ] PASS / FAIL
- Evidence: ___

### C3: Invalid Format
```
ACTION: Try to register "bad cid name!"
VERIFY: Rejected or sanitized
```
- [ ] PASS / FAIL
- Evidence: ___

### C4: Remove CID
```
ACTION: Remove D04 from registry
VERIFY: No longer in Section 2
```
- [ ] PASS / FAIL
- Evidence: ___

### C5: Path Update
```
ACTION: Move DATA-002.md, update registry path
VERIFY: CID D02 still resolves
```
- [ ] PASS / FAIL
- Evidence: ___

### C6: Orphan Scan
```
ACTION: Delete file but keep CID in registry
VERIFY: Mismatch detected on scan
```
- [ ] PASS / FAIL
- Evidence: ___

---

## Suite D: Expansion (5 tests)

### D1: New Data File
```
ACTION: Request new Data file creation
VERIFY: User confirmation required, registry entry added
```
- [ ] PASS / FAIL
- Evidence: ___

### D2: New Skill File
```
ACTION: Request new Skill file creation
VERIFY: User confirmation required, registry entry added
```
- [ ] PASS / FAIL
- Evidence: ___

### D3: New Project
```
ACTION: Request new Project folder
VERIFY: Only root folder + index need confirmation
```
- [ ] PASS / FAIL
- Evidence: ___

### D4: Project Local File
```
ACTION: Create file inside PROJECT-001
VERIFY: No registry entry, listed in project index
```
- [ ] PASS / FAIL
- Evidence: ___

### D5: Outside Project
```
ACTION: Try to create file in vault root
VERIFY: Blocked or requires confirmation
```
- [ ] PASS / FAIL
- Evidence: ___

---

## Suite E: Self-Healing (4 tests)

### E1: Orphan CID Detection
```
ACTION: Move file to _trash, keep CID
VERIFY: Scan detects missing file
```
- [ ] PASS / FAIL
- Evidence: ___

### E2: Orphan File Detection
```
ACTION: Create file without registry entry
VERIFY: Scan optionally flags unregistered file
```
- [ ] PASS / FAIL
- Evidence: ___

### E3: Path Repair
```
ACTION: Move file, CID should still resolve
VERIFY: Use CID metadata to find new location
```
- [ ] PASS / FAIL
- Evidence: ___

### E4: 10th Operation Check
```
ACTION: Perform 10 operations
VERIFY: Registry verification triggers
```
- [ ] PASS / FAIL
- Evidence: ___

---

## Suite F: Edge Cases (6 tests)

### F1: Unicode Content
```
ACTION: Read unicode-שלום.md
VERIFY: Hebrew/Arabic/Chinese renders correctly
```
- [ ] PASS / FAIL
- Evidence: ___

### F2: Spaces in Path
```
ACTION: Read "spaces in name.md"
VERIFY: No path resolution errors
```
- [ ] PASS / FAIL
- Evidence: ___

### F3: Empty File
```
ACTION: Read DATA-EMPTY.md
VERIFY: Returns empty, no crash
```
- [ ] PASS / FAIL
- Evidence: ___

### F4: Malformed Skill
```
ACTION: Read SKILL-BROKEN.md
VERIFY: Readable despite broken format
```
- [ ] PASS / FAIL
- Evidence: ___

### F5: Deep Nesting
```
ACTION: Access PROJECT-001/logs/log-001.md via path
VERIFY: Resolves correctly
```
- [ ] PASS / FAIL
- Evidence: ___

### F6: Large Registry Simulation
```
ACTION: Add 50 dummy CIDs, then search
VERIFY: Performance < 2 seconds
```
- [ ] PASS / FAIL
- Evidence: Time = ___

---

## Results Summary

| Suite | Passed | Failed |
|-------|--------|--------|
| A: Routing | /10 | |
| B: Staging | /8 | |
| C: Registry | /6 | |
| D: Expansion | /5 | |
| E: Self-Heal | /4 | |
| F: Edge Case | /6 | |
| **TOTAL** | **/39** | |

---

## Post-Test Cleanup

- [ ] Reset DATA-001.md to original
- [ ] Clear _trash folder  
- [ ] Clear _update folder
- [ ] Remove any test-created files
- [ ] Restore moved files to original locations