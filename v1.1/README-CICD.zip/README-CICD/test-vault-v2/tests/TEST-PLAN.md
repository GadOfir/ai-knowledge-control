# TEST PLAN – Real Regression Testing for v1.1-CANDIDATE

**Created:** 2025-12-25  
**Purpose:** Execute REAL tests, not documentation audits

---

## Test Environment Setup

**Test Vault Location:** `/README-CICD/test-vault-v2/`  
**README Under Test:** `/versions/v1.1-CANDIDATE/README.md`  
**Test Executor:** Claude via Obsidian MCP

---

## Phase 1: Environment Setup

### 1.1 Create Test Vault Structure

```
test-vault-v2/
├── README.md              ← Copy of v1.1-CANDIDATE (our test subject)
├── data/
│   ├── DATA-001.md        ← Real Data CID
│   ├── DATA-002.md        ← Second Data CID
│   └── DATA-EMPTY.md      ← Edge case: empty file
├── skills/
│   ├── SKILL-001.md       ← Real Skill CID
│   └── SKILL-BROKEN.md    ← Edge case: malformed skill
├── projects/
│   └── PROJECT-001/
│       ├── PROJECT-INDEX.md
│       ├── artifact-1.md
│       └── logs/
│           └── log-001.md
├── _update/               ← Staging area for tests
└── edge-cases/
    ├── unicode-שלום.md    ← Unicode filename
    ├── spaces in name.md  ← Spaces in filename
    └── CAPS.MD            ← Case sensitivity
```

---

## Phase 2: Test Scenarios

### TEST SUITE A: Routing Tests (Section 3)

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| A1 | Find Data by CID | Query "find DATA-001" | Returns path to DATA-001.md | |
| A2 | Find Skill by CID | Query "find SKILL-001" | Returns path to SKILL-001.md | |
| A3 | Find Project by CID | Query "find PROJECT-001" | Returns PROJECT-INDEX.md path | |
| A4 | Find by Purpose | Query "find config data" | Returns matching CID | |
| A5 | Find non-existent | Query "find FAKE-999" | Returns "not found" + growth protocol | |
| A6 | Ambiguous query | Query "find data" | Returns list of matches or asks clarification | |
| A7 | Case insensitive | Query "find data-001" | Matches DATA-001 | |
| A8 | Registry empty | Remove all CIDs from registry | Phase B triggers | |
| A9 | Circular reference | CID A points to CID B points to CID A | Detect loop, don't crash | |
| A10 | Deep nesting | PROJECT-001/sub1/sub2/sub3/file.md | Resolves correctly | |

---

### TEST SUITE B: Staging Tests (Section 4)

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| B1 | Create _update | Modify DATA-001 content | Creates DATA-001_update.md | |
| B2 | Reconcile _update | User approves | Original replaced, _update deleted | |
| B3 | Reject _update | User rejects | _update deleted, original unchanged | |
| B4 | Multiple _updates | Create 3 _update files | All tracked, reconciled in order | |
| B5 | Concurrent _update | Two _updates for same file | Conflict detected, user chooses | |
| B6 | Empty _update | Create blank _update file | Rejected or warned | |
| B7 | _update in wrong location | Create in root instead of near target | System handles or rejects | |
| B8 | Direct write attempt | Try to write directly to DATA-001 | BLOCKED - must use staging | |
| B9 | afterAIreview flow | User manually edits file | Creates _afterAIreview.md | |
| B10 | Nested _update | _update inside project folder | Follows project autonomy rules | |

---

### TEST SUITE C: Registry Tests (Section 2)

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| C1 | Add new CID | Register DATA-003 | Appears in Section 2 table | |
| C2 | Remove CID | Delete DATA-002 entry | Removed from registry | |
| C3 | Update CID path | Move file, update registry | Path resolves correctly | |
| C4 | Duplicate CID | Try to add existing CID | Rejected | |
| C5 | Invalid CID format | Add "bad cid name" | Rejected or sanitized | |
| C6 | Missing file | CID points to deleted file | Self-healing detects | |
| C7 | Registry > 50 CIDs | Add many entries | Performance acceptable | |
| C8 | Registry corruption | Malformed table | System recovers or alerts | |

---

### TEST SUITE D: Expansion Tests (Section 5)

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| D1 | Create Data file | Request new data file | User confirmation + registry entry | |
| D2 | Create Skill file | Request new skill | User confirmation + registry entry | |
| D3 | Create Project | Request new project | Only root + index need confirmation | |
| D4 | Project local file | Add file inside project | No registry entry needed | |
| D5 | Project subfolder | Create subfolder in project | Allowed without confirmation | |
| D6 | File outside project | Try to create in root | Blocked unless UPDATE_STRATEGY allows | |
| D7 | UPDATE_STRATEGY=2 | Set proposal mode | Must ask before creating _update | |
| D8 | UPDATE_STRATEGY=3 | Set read-only | All writes blocked | |

---

### TEST SUITE E: Self-Healing Tests (Section 6)

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| E1 | 10th operation check | Perform 10 operations | Registry verification triggers | |
| E2 | 20 entries summary | Add 20 log entries | Summary proposed via _update | |
| E3 | File moved | Move DATA-001.md | Path repair via CID lookup | |
| E4 | File deleted | Delete DATA-001.md | Mismatch detected, user alerted | |
| E5 | Orphan CID | CID exists, file doesn't | Correction proposed | |
| E6 | Orphan file | File exists, no CID | Optionally propose registration | |

---

### TEST SUITE F: Edge Cases

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| F1 | Unicode filename | Access unicode-שלום.md | Resolves correctly | |
| F2 | Spaces in filename | Access "spaces in name.md" | Resolves correctly | |
| F3 | Case sensitivity | CAPS.MD vs caps.md | Consistent behavior | |
| F4 | Empty file | Read DATA-EMPTY.md | Handled gracefully | |
| F5 | Malformed skill | Execute SKILL-BROKEN.md | Error reported, no crash | |
| F6 | Very long filename | 255 character filename | Handled or rejected | |
| F7 | Deep path | 10 levels of nesting | Resolves or hits limit | |
| F8 | Special chars | File with !@#$% in name | Handled appropriately | |
| F9 | Null bytes | File with \x00 in content | Handled gracefully | |
| F10 | Large file | 10MB markdown file | Performance acceptable | |

---

### TEST SUITE G: Pipeline Integration

| ID | Scenario | Action | Expected Result | Actual Result |
|----|----------|--------|-----------------|---------------|
| G1 | GATE 0 clean | Run pre-flight on v1.1-CANDIDATE | PASS - clean baseline | |
| G2 | GATE 0 dirty | Run pre-flight on populated README | FAIL - contamination detected | |
| G3 | S02 parse | Parse v1.1-CANDIDATE | Valid JSON output | |
| G4 | S03 deps | Map section dependencies | DAG with no cycles | |
| G5 | S04 impact | Compare v1.0 vs v1.1 | Risk assessment generated | |
| G6 | S06 contract | Validate v1.1 contract | 7/7 principles pass | |
| G7 | S07 compat | Run against test vault | All CIDs accessible | |
| G8 | Full pipeline | End-to-end improvement | Completes all gates | |

---

## Phase 3: Execution

Each test will be executed with:
1. **Setup** - Create required preconditions
2. **Action** - Perform the test operation
3. **Verify** - Check actual vs expected
4. **Cleanup** - Reset for next test
5. **Log** - Record pass/fail + evidence

---

## Phase 4: Results Template

```markdown
## Test Execution Report

**Date:** YYYY-MM-DD HH:MM
**Executor:** Claude
**Environment:** test-vault-v2

### Summary
- Total Tests: XX
- Passed: XX
- Failed: XX
- Skipped: XX

### Failed Tests
| ID | Reason | Evidence |
|----|--------|----------|
| XX | [why it failed] | [file/output] |

### Issues Discovered
1. [Issue description]
   - Severity: HIGH/MEDIUM/LOW
   - Impact: [what breaks]
   - Fix: [proposed solution]
```

