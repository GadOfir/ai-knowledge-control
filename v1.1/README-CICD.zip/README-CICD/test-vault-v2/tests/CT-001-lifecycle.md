# COMPLEX TEST 001: Full CID Lifecycle + Cross-References

**Test ID:** CT-001  
**Started:** 2025-12-25 18:10  
**Status:** EXECUTING

---

## TEST SCENARIO

Simulate a real workflow:
1. User requests new Data file for "database credentials"
2. System creates file following Section 5 rules
3. System registers in Section 2
4. User requests to find "database" - routing must work
5. User modifies the file - staging must work
6. Skill file references the data file - cross-ref must work
7. Create file inside project WITHOUT registry - autonomy must work
8. Move a file - self-healing must detect

---

## STEP 1: Create New Data File (Section 5 Rules)

**Rule Check:** Data files require user confirmation + registry entry

**Action:** Create DATA-CREDS.md for database credentials
