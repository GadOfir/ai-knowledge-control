# DATA-001 – Server Configuration Reference

**Metadata:** [Type: Data | Strategy: `1`]  
**Active Context:** [CID: D01 | Task: Store server configuration]

---

## Purpose

Reference data for server configuration used in deployment.

---

## Content

```yaml
server:
  name: prod-server-01
  ip: 192.168.1.100
  port: 8080
  environment: production
  
database:
  host: db.internal
  port: 5432
  name: app_production
  
features:
  - logging: enabled
  - metrics: enabled
  - cache: redis
```

---

## Notes

This is real test data for routing verification.