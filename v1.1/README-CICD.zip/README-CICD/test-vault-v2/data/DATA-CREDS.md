# DATA-CREDS – Database Credentials Reference

**Metadata:** [Type: Data | Strategy: `1`]  
**Active Context:** [CID: D04 | Task: Store database credentials reference]

---

## Purpose

Secure reference for database connection credentials.

---

## Content

```yaml
database:
  production:
    host: db-prod.internal
    port: 5432
    user: app_user
    password_ref: vault://secrets/db-prod
    
  staging:
    host: db-stage.internal
    port: 5432
    user: app_user
    password_ref: vault://secrets/db-stage
```

---

## Access Rules

- Production: Requires VPN + MFA
- Staging: Requires VPN only

---

## Notes

Created by CT-001 test at 2025-12-25