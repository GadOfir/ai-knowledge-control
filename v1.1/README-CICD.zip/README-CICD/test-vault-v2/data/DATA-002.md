# DATA-002 – API Endpoints Reference

**Metadata:** [Type: Data | Strategy: `1`]  
**Active Context:** [CID: D02 | Task: Store API endpoint documentation]

---

## Purpose

Reference data for API endpoints.

---

## Content

| Endpoint | Method | Description |
|----------|--------|-------------|
| /api/users | GET | List all users |
| /api/users/{id} | GET | Get user by ID |
| /api/users | POST | Create user |
| /api/health | GET | Health check |

---

## Notes

Second data file for multi-CID routing tests.