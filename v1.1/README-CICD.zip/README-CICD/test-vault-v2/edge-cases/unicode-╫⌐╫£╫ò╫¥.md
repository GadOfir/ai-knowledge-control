# Unicode Test – שלום עולם

**Metadata:** [Type: Data | Strategy: `1`]  
**Active Context:** [CID: E01 | Task: Test unicode filename handling]

---

## Purpose

Tests that the system handles unicode filenames correctly.

---

## Content

Hebrew: שלום עולם (Hello World)
Arabic: مرحبا بالعالم
Chinese: 你好世界
Japanese: こんにちは世界
Russian: Привет мир
Emoji: 🎉🚀✅

---

## Notes

If you can read this file via CID E01, unicode routing works.