# TEST-PROJECT-01 – Sample Project

**Metadata:** [Type: Project | Strategy: `1`]  
**Active Context:** [CID: TEST-P01 | Task: Test Project for Regression Testing]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING ONLY, project autonomy within folder
- **Task:** Demonstrate Project-type CID functionality
- **Expected Output:** Project artifacts in local folder

---

## Purpose

This is a minimal Project-type CID for testing:
- Section 5 project autonomy rules
- Local file creation within project folder
- Project index maintenance

---

## Project File Registry

| File Path | Purpose | Created By |
|-----------|---------|------------|
| `PROJECT-INDEX.md` | This file | AI Initiative |
| `test-artifact.md` | Test artifact | AI Initiative |

---

## Notes

This project is ONLY for testing. It contains no real work.
