# TEST-SKILL-01 – Sample Skill File

**Metadata:** [Type: Skill | Strategy: `1`]  
**Active Context:** [CID: TEST-S01 | Task: Test Skill for Regression Testing]

---

## Execution Prompt

- **Authority:** README.md | Update Strategy: Inherited
- **Rules:** STAGING ONLY
- **Task:** Demonstrate Skill-type CID functionality
- **Expected Output:** Staged test output

---

## Purpose

This is a minimal Skill-type CID for testing README execution and routing.

---

## Decision Chains

```
IF test requested:
  → Execute test procedure
  → Stage results in _update file
  → Report success
```

---

## Common Commands

```bash
# Test command
echo "Test executed successfully"
```

---

## Notes

This file is ONLY for testing. It contains no real skill logic.
