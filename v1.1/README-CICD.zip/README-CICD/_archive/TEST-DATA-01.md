# TEST-DATA-01 – Sample Data File

**Metadata:** [Type: Data | Strategy: `1`]  
**Active Context:** [CID: TEST-D01 | Task: Test Data for Regression Testing]

---

## Purpose

This is a minimal Data-type CID for testing README routing and registry functionality.

---

## Test Data

**Sample Configuration:**
```yaml
service: test-service
port: 8080
environment: sandbox
```

**Purpose:** Verify that Data-type CIDs can be:
1. Located via Section 3 routing
2. Read successfully
3. Maintained in Section 2 registry

---

## Notes

This file is ONLY for testing. It contains no real data.
