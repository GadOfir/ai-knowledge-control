# S02-Constitutional-Parser – README Structure Analyzer

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S02-PARSE | Task: Parse README Into Structured Data]

---

## Purpose

Treats README as structured data. Extracts sections, dependencies, criticality, and core contract.

---

## Pre-Parse Validation

See **S01 Pre-Flight Validation** for source checks.

**Clean Baseline:** Section 8 = INITIALIZING, Registry = R01 only, No test data.

---

## Decision Chain

```
Input: README.md + source metadata
  ↓
Validate clean baseline (ref: S01)
  ↓
Extract sections 1-8 → Build hierarchy
  ↓
Map dependencies → Which sections reference which?
  ↓
Classify criticality:
  CORE_CONTRACT: Section 1, 4
  ROUTING: Section 2, 3
  EXPANSION: Section 5
  MAINTENANCE: Section 6, 7, 8
  ↓
Extract immutable principles → Core contract JSON
  ↓
Output: Parsed README JSON + dependency graph
```

---

## Section Criticality

| Section | Type | Breaking Risk |
|---------|------|---------------|
| 1 | CORE_CONTRACT | CATASTROPHIC |
| 2 | ROUTING | HIGH |
| 3 | ROUTING | HIGH |
| 4 | SAFETY | CATASTROPHIC |
| 5 | EXPANSION | MODERATE |
| 6 | MAINTENANCE | LOW |
| 7 | TEMPLATE | LOW |
| 8 | STATE | NONE |

---

## Output Structure

```json
{
  "version": "v1.0",
  "state": "PROD",
  "sections": [
    {"id": "section_1", "criticality": "CORE_CONTRACT", "dependents": ["4","5","6"]}
  ],
  "core_contract": {
    "immutable_principles": [
      "README is authority",
      "No direct writes",
      "Staging mandatory",
      "User approval required"
    ]
  },
  "dependency_graph": {
    "roots": ["section_1", "section_2"],
    "load_bearing": ["section_1", "section_4"]
  }
}
```

---

## Key Learnings

- Section 1 + 4 are load-bearing walls
- Section 8 state = canary for dirty README
- Registry size > 1 = contaminated