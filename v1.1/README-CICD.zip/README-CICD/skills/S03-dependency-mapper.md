# S03-Dependency-Mapper – Section Relationship Analyzer

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S03-DEPMAP | Task: Map README Section Dependencies]

---

## Purpose

Creates a **directed acyclic graph (DAG)** of section dependencies showing which sections depend on which others, enabling accurate blast radius calculation for changes.

---

## Decision Chains

```
Input: Parsed README JSON from S02
  ↓
Extract all section references
  (e.g., "Section 4 references Section 1")
  ↓
Build dependency edges:
  Section 1 → Section 4
  Section 1 → Section 5
  Section 4 → Section 3
  Section 2 → Section 3
  Section 3 → Section 5
  Section 5 → Section 6
  ↓
Identify:
  - Root nodes (no dependencies)
  - Load-bearing nodes (many dependents)
  - Leaf nodes (no dependents)
  - Critical paths
  ↓
Calculate transitive dependencies:
  Section 1 affects: 4, 3, 5, 6 (CATASTROPHIC blast radius)
  Section 7 affects: none (SAFE to change)
  ↓
Output dependency graph JSON
```

---

## Output Structure

```json
{
  "dependency_graph": {
    "section_1": {
      "direct_dependents": ["section_4", "section_5"],
      "transitive_dependents": ["section_3", "section_6"],
      "blast_radius": "CATASTROPHIC",
      "is_root": true,
      "is_load_bearing": true
    },
    "section_4": {
      "dependencies": ["section_1"],
      "direct_dependents": ["all_operations"],
      "blast_radius": "CATASTROPHIC",
      "is_safety_critical": true
    }
  },
  "critical_paths": [
    ["section_1", "section_4", "all_operations"],
    ["section_2", "section_3", "all_operations"]
  ]
}
```

---

## Key Learnings

- **Transitive dependencies matter** - changing Section 1 affects 4, 3, 5, 6
- **Load-bearing sections** require extra scrutiny (Section 1, 4, 2, 3)
- **Leaf nodes are safer** to modify (Section 7, 8)
