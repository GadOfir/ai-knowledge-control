# S04-Impact-Analyzer – Change Consequence Predictor

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S04-IMPACT | Task: Predict Change Blast Radius]

---

## Purpose

Predicts change consequences: structural, semantic, behavioral, compatibility impacts. Discovers edge cases and feeds them to S07.

---

## Pre-Analysis Validation

See **S01 Pre-Flight Validation**. Both OLD and NEW versions must be [PROD] or fetchable.

| Old | New | Action |
|-----|-----|--------|
| [PROD] | [PROD] | ✅ Proceed |
| [PROD] | [WIP] | ⚠️ Warn |
| [DIRTY] | any | ❌ Auto-fetch |

---

## Decision Chain

```
Validate versions → Structural analysis → Semantic analysis
  ↓
Blast radius (from S03 graph) → Risk classification
  ↓
Deep breakage analysis → Edge case discovery → S07 test pool update
  ↓
AI opinion (prose) → Output report
```

---

## Risk Classification

| Level | Criteria |
|-------|----------|
| 🟢 SAFE | 0 breaking, <10% affected |
| 🟡 MODERATE | 0 breaking, 10-50% affected |
| 🟠 BREAKING | 1+ breaking, <50% affected |
| 🔴 CATASTROPHIC | Core contract change OR >50% affected |

---

## Output Structure

```markdown
### Change: [description]

**Blast Radius:** [level]
- Affects: X%
- Breaking: N
- Rollback: EASY/MEDIUM/HARD

**Dependency Chain:** A → B → C

---

### 🔬 Deep Breakage Analysis

| Removed | Used In | Effect |
|---------|---------|--------|
| [x] | [y] | [z] |

| Old | New | Why Breaking |
|-----|-----|--------------|
| [a] | [b] | [c] |

**Cascade:** Change → Fail1 → Fail2 → Final

---

### 🧪 Edge Cases → Add to S07

| Case | Trigger | Failure |
|------|---------|---------|
| Empty input | null | crash |
| Concurrent | parallel | race |

---

### 💭 AI Opinion

[~10 sentences prose. Intent vs impact. QA view. Reversibility. Alternatives. Verdict.]

---

**Recommendation:** ✅ / ⚠️ / ❌
```

---

## Key Learnings

- Validate BOTH versions before compare
- Section 1 or 4 change = auto CATASTROPHIC
- Edge cases → S07 test pool
- AI opinion in prose, not bullets