# S12-Slop-Reducer – AI Writing Quality Enforcer

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S12-SLOP | Task: Remove AI Verbosity From Skills]

---

## Purpose

Enforces tight, professional writing in all skill files by detecting and removing AI slop patterns.

---

## What Is Slop?

Filler words, redundant phrases, over-explanation, excessive formatting that adds no value.

---

## Slop Patterns to Remove

| Pattern | Example | Fix |
|---------|---------|-----|
| Excitement markers | "This is where we find out!" | Delete |
| Redundant emphasis | "CRITICAL: This is very important" | Pick one |
| Over-explanation | Explaining what code does line-by-line | Trust reader |
| Repeated validation | Same check in 5 skills | Centralize or reference |
| Filler phrases | "It's important to note that" | Delete |
| Excessive emoji | "✅ ⚠️ 🔴 🟢 ❌" everywhere | Use sparingly |
| Verbose headers | "Key Learnings From Our Experience" | "Key Learnings" |
| Template bloat | 50-line example when 10 suffices | Condense |
| Stating the obvious | "If tests fail, tests have failed" | Delete |
| Hedging | "basically", "essentially", "actually" | Delete |

---

## Decision Chain

```
Input: Skill file content
  ↓
Scan for slop patterns
  ↓
For each pattern found:
  - Flag location
  - Suggest fix (delete/condense/reference)
  ↓
Calculate slop score:
  - Lines of content vs lines of value
  - Duplicate content percentage
  - Filler word density
  ↓
If slop > 20%:
  - Generate _update file with cleaned version
  - Preserve all functional content
  - Remove only filler
  ↓
Output: Clean skill file
```

---

## Quality Rules

1. **One validation section per pipeline** - other skills reference it
2. **Examples: 10 lines max** unless complexity demands more
3. **No filler phrases** - get to the point
4. **Emoji: max 3 per section** - visual noise otherwise
5. **Headers: 3 words or less** when possible
6. **Key Learnings: max 5 bullets** - only novel insights
7. **No duplicate content** - link to source skill instead

---

## Reference Pattern

When content exists elsewhere:
```markdown
## Validation
See S01-orchestrator.md → Pre-Flight Validation
```

Not:
```markdown
## ⚠️ CRITICAL: Production State Verification (PRE-FLIGHT)

**Rule:** NEVER analyze a README without verifying its production state.

### Known Production Source
... (50 more lines of duplicate content)
```

---

## Slop Score Calculation

```
slop_score = (filler_lines + duplicate_lines) / total_lines * 100

GREEN: < 10% slop
YELLOW: 10-20% slop  
RED: > 20% slop → Requires cleanup
```

---

## Key Learnings

- Verbose ≠ thorough
- Readers skip walls of text
- Duplicate content drifts out of sync
- Tight writing = faster comprehension