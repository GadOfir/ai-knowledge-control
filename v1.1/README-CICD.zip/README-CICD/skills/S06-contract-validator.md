# S06-Contract-Validator – Core Contract Enforcement

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S06-CONTRACT | Task: Ensure Core Contract Integrity]

---

## Purpose

Automated enforcement of immutable principles. Any violation = auto-reject.

---

## Pre-Validation

See **S01 Pre-Flight Validation**. Core contract must be from [PROD] baseline.

---

## Core Contract (7 Principles)

1. README is single source of truth
2. AI forbidden from direct writes
3. All changes staged in _update files
4. User has final approval authority
5. System must support rollback
6. CID system must remain functional
7. Registry must be maintainable

---

## Validation Tests

| Test | Validates | Fail Message |
|------|-----------|--------------|
| 1 | Authority declared | "Authority principle violated" |
| 2 | Direct writes forbidden | "Safety protocol violated" |
| 3 | _update staging required | "Staging mechanism broken" |
| 4 | User approval in place | "User control compromised" |
| 5 | Rollback supported | "Rollback capability lost" |
| 6 | CID routing works | "CID system broken" |
| 7 | Registry updatable | "Registry unmaintainable" |

**Result:** All 7 pass → APPROVE | Any fail → BLOCK

---

## Output

```markdown
## Contract Validation: v1.1-CANDIDATE

✅ 7/7 tests passed
RECOMMENDATION: APPROVE for further testing
```

---

## Key Learnings

- All 7 must pass - no exceptions
- This is GATE 3 - automated, no user input