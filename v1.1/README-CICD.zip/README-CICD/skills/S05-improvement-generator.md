# S05-Improvement-Generator – Enhancement Proposal Engine

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S05-IMPROVE | Task: Create README Enhancement Proposals]

---

## Purpose

Generates enhancement proposals prioritizing backward compatibility and incremental rollout.

---

## Decision Chain

```
Input: Requirements + README analysis + dependency graph
  ↓
Identify affected sections
  ↓
Generate proposals (preference order):
  1. Non-breaking additions
  2. Clarifications
  3. Non-breaking modifications
  4. Breaking modifications (last resort)
  ↓
Classify risk per proposal
  ↓
Output proposal document
```

---

## Proposal Template

```markdown
## Proposal: [Title]

**Risk:** 🟢 SAFE / 🟡 MODERATE / 🟠 BREAKING / 🔴 CATASTROPHIC

**Changes:**
- Section X: [modification]
- Section Y: [addition]

**Affected:** Sections X, Y, Z
**Breaking:** None / [list]

**Rollback:** [steps to restore]

**Alternative:** [less risky option]
```

---

## Key Learnings

- Additions > modifications
- Breaking changes need justification
- Always include rollback