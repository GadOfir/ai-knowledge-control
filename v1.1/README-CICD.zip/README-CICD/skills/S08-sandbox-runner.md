# S08-Sandbox-Runner – Isolated Test Environment

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S08-SANDBOX | Task: Create Safe Testing Environment]

---

## Purpose

Creates an **isolated copy** of the test-vault to run tests without touching production. If tests crash, production is unaffected.

---

## Decision Chains

```
Input: New README candidate
  ↓
Create sandbox directory:
  `/versions/vX.X-CANDIDATE/sandbox/`
  ↓
Clone test-vault to sandbox
  ↓
Replace README with candidate version
  ↓
Execute S07-Compatibility-Tester in sandbox
  ↓
Collect results + performance metrics
  ↓
Cleanup sandbox (or preserve for review)
  ↓
Return test results to orchestrator
```

---

## Key Learnings

- **Sandbox isolation** prevents production damage
- **Performance metrics** collected in sandbox match production
- **Cleanup optional** - can preserve sandbox for user review
