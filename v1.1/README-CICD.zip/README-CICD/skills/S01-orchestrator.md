# S01-Orchestrator – Master CICD Controller

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S01-ORCH | Task: Coordinate README Improvement Pipeline]

---

## Purpose

Single entry point for README improvements. Coordinates S02-S11 through 5-gate approval process.

---

## Pre-Flight Validation

**Canonical Source:** `https://github.com/GadOfir/ai-knowledge-control/blob/main/V1/README.md`

| Check | Expected | On Fail |
|-------|----------|---------|
| Source | GitHub [PROD] | Auto-fetch |
| Section 8 | INITIALIZING | Reject: "State Contamination" |
| Registry | R01 only | Reject: "Registry populated" |

---

## Pipeline Flow

```
@improve-readme <requirements>
  ↓
GATE 0: Pre-flight validation
  ↓
GATE 1: User confirms proceed? → S02 parse → S03 deps → S05 proposals → S04 impact
  ↓
GATE 2: User approves impact? → S06 contract validation
  ↓
GATE 3: Contract passes? (auto) → S08 sandbox → S07 tests
  ↓
GATE 4: Tests pass? (auto) → S09 migration plan
  ↓
GATE 5: User approves migration? → S11 stage
  ↓
FINAL: User confirms production? → Deploy + monitor
```

---

## Commands

| Command | Action |
|---------|--------|
| `@improve-readme: <req>` | Start pipeline |
| `@emergency-rollback to vX.X` | Restore version |
| `@pipeline-status` | Check progress |

---

## State Tracking

```json
{
  "pipeline_id": "pip_YYYYMMDD_HHMMSS",
  "current_gate": "GATE_N",
  "candidate_version": "vX.X-CANDIDATE",
  "status": "AWAITING_USER_APPROVAL"
}
```

---

## Key Learnings

- Pre-flight validation prevents 90% of failures
- Auto-fetch from GitHub eliminates source confusion
- 5-gate process requires clear user communication