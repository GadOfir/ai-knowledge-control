# S07-Compatibility-Tester – Real Regression Test Suite

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S07-COMPAT | Task: Execute Real Tests Against Test Vault]

---

## Purpose

Executes **real, verifiable regression tests** against a populated test vault. Not documentation audits - actual operations.

---

## Test Vault Location

```
/README-CICD/test-vault-v2/
├── README.md              ← Populated test README (10 CIDs)
├── data/
│   ├── DATA-001.md        ← D01: Server config
│   ├── DATA-002.md        ← D02: API endpoints
│   └── DATA-EMPTY.md      ← D03: Empty file edge case
├── skills/
│   ├── SKILL-001.md       ← S01: Deployment skill
│   └── SKILL-BROKEN.md    ← S02: Malformed skill edge case
├── projects/
│   └── PROJECT-001/
│       ├── PROJECT-INDEX.md  ← P01: Project index
│       ├── artifact-1.md     ← Local file (no registry)
│       └── logs/log-001.md   ← Nested local file
├── edge-cases/
│   ├── unicode-שלום.md    ← E01: Unicode filename
│   ├── spaces in name.md  ← E02: Spaces in filename
│   └── CAPS.MD            ← E03: Case sensitivity
└── _update/               ← Staging area
```

---

## Test Suites

### Suite A: Routing (10 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| A1 | CID lookup | Read registry, find D01 | Path = `data/DATA-001.md` |
| A2 | File access | Open D01 path | Content readable, CID matches |
| A3 | Type filter | Find all Data types | Returns D01, D02, D03, E01, E02, E03 |
| A4 | Purpose search | Find "server config" | Returns D01 |
| A5 | Project routing | Find P01 | Returns PROJECT-INDEX.md |
| A6 | Nested access | Access P01/logs/log-001.md | File readable |
| A7 | Non-existent CID | Find "FAKE-999" | Returns not found + Phase B trigger |
| A8 | Case sensitivity | Find "d01" vs "D01" | Consistent behavior |
| A9 | Unicode path | Access E01 | File readable |
| A10 | Spaces path | Access E02 | File readable |

### Suite B: Staging (8 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| B1 | Create _update | Modify D01 | `DATA-001_update.md` created |
| B2 | Original unchanged | Check D01 after B1 | Size/time identical |
| B3 | Reconcile | Merge _update → original | Content merged |
| B4 | Cleanup | After reconcile | _update file deleted/moved |
| B5 | Reject flow | User rejects _update | Original unchanged, _update removed |
| B6 | Concurrent _update | Two _updates same file | Conflict detected |
| B7 | Direct write block | Attempt write without _update | Operation blocked |
| B8 | afterAIreview | Simulate manual edit | Creates _afterAIreview.md |

### Suite C: Registry (6 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| C1 | Add CID | Register new D04 | Appears in Section 2 |
| C2 | Duplicate CID | Add existing D01 | Rejected |
| C3 | Invalid format | Add "bad cid!" | Rejected or sanitized |
| C4 | Remove CID | Delete D04 entry | Gone from registry |
| C5 | Path update | Move file, update path | New path resolves |
| C6 | Orphan scan | CID points to deleted file | Mismatch detected |

### Suite D: Expansion (5 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| D1 | New Data | Create Data file | User confirm + registry |
| D2 | New Skill | Create Skill file | User confirm + registry |
| D3 | New Project | Create Project folder | Only root + index confirmed |
| D4 | Project local | Add file inside P01 | No registry, listed in index |
| D5 | Outside project | Create file in root | Blocked or requires confirm |

### Suite E: Self-Healing (4 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| E1 | Orphan CID | Delete file, keep registry | Detected on scan |
| E2 | Orphan file | Add file, no registry | Optionally flagged |
| E3 | Path repair | Move file | CID lookup still works |
| E4 | Registry verify | Run 10th operation check | All CIDs validated |

### Suite F: Edge Cases (6 tests)

| ID | Test | Action | Pass Criteria |
|----|------|--------|---------------|
| F1 | Unicode | Read unicode-שלום.md | Content correct |
| F2 | Spaces | Read "spaces in name.md" | Content correct |
| F3 | Empty file | Read DATA-EMPTY.md | No crash, empty returned |
| F4 | Malformed | Read SKILL-BROKEN.md | Readable, no crash |
| F5 | Deep nest | Access P01/logs/log-001.md | Resolves correctly |
| F6 | Large registry | 50+ CIDs | Performance acceptable |

---

## Execution Protocol

```
FOR each test suite:
  1. SETUP: Create preconditions
  2. EXECUTE: Run the action
  3. VERIFY: Check actual vs expected
  4. RECORD: Log PASS/FAIL + evidence
  5. CLEANUP: Reset for next test

EVIDENCE REQUIRED:
  - File sizes before/after
  - Timestamps before/after
  - Actual file content (first 100 chars)
  - Error messages if any
```

---

## Results Template

```markdown
## Test Run: [DATE]

### Summary
| Suite | Passed | Failed | Total |
|-------|--------|--------|-------|
| A: Routing | X | Y | 10 |
| B: Staging | X | Y | 8 |
| C: Registry | X | Y | 6 |
| D: Expansion | X | Y | 5 |
| E: Self-Heal | X | Y | 4 |
| F: Edge Case | X | Y | 6 |
| **TOTAL** | **X** | **Y** | **39** |

### Failed Tests
| ID | Expected | Actual | Evidence |
|----|----------|--------|----------|

### Issues Found
1. [Description] - Severity: HIGH/MED/LOW
```

---

## Key Rules

- **No fake tests** - every test must execute real operations
- **Evidence required** - file sizes, timestamps, content snippets
- **Atomic tests** - each test independent, cleanup after
- **39 total tests** - all must pass for GATE 4