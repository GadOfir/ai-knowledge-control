# S11-Version-Controller – Git-Like Version Management

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S11-VERSION | Task: Manage README Version History]

---

## Purpose

Manages README versions with semantic versioning, state markers, and immutability enforcement.

---

## Versioning Rules

| Type | Example | Trigger |
|------|---------|---------|
| MAJOR | v2.0 | Breaking changes to core contract |
| MINOR | v1.1 | New sections, enhancements |
| PATCH | v1.0.1 | Typos, clarifications |

---

## State Markers

| Marker | Meaning |
|--------|---------|
| [PROD] | Production-ready, canonical |
| [WIP] | Work in progress |
| [DIRTY] | Contains test/populated data |
| [FROZEN] | Candidate passed gates, immutable |

---

## Promotion Flow

```
Create /versions/vX.X-CANDIDATE/ [WIP]
  ↓
Pipeline validates (S01-S10)
  ↓
Gates pass → Mark [FROZEN]
  ↓
COPY to vault/README.md (populate there only)
  ↓
CANDIDATE stays: 0%, R01 only, INITIALIZING
  ↓
Rename to /versions/vX.X/ [PROD]
  ↓
Update .active-version
```

---

## Candidate Immutability

**Rule:** CANDIDATE = immutable template after gate passage.

See **S09 Phase 4** for enforcement details.

| Location | Modified? |
|----------|-----------|
| vault/README.md | ✅ YES (100%) |
| vX.X-CANDIDATE/ | ❌ NEVER (0%) |

---

## Metadata

```json
{
  "version": "v1.1",
  "state": "PROD",
  "section_8_state": "INITIALIZING",
  "registry_cids": ["R01"],
  "gates_passed": ["G0","G1","G2","G3","G4","G5","FINAL"]
}
```

---

## Key Learnings

- State markers prevent confusion
- CANDIDATE immutability = clean templates forever
- Copy, never modify candidates