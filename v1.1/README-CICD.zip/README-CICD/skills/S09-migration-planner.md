# S09-Migration-Planner – Version Transition Architect

**Metadata:** [Type: Skill | Strategy: `1` (Build)]  
**Active Context:** [CID: S09-MIGRATE | Task: Plan Safe Version Transitions]

---

## Purpose

Creates step-by-step migration guides. Full regression runs AFTER deployment to detect real-world issues.

---

## Migration Phases

| Phase | Action | Rollback |
|-------|--------|----------|
| 1. Prep | User reviews reports | Cancel |
| 2. Approval | User says "yes" or "no" | Stop pipeline |
| 3. Stage | Create README_update.md | Delete staged file |
| 4. Promote | COPY candidate → vault, populate vault | Restore old_README |
| 5. Test | Run S07 on production | Mark FAILED_REGRESSION |
| 6. Handle | If fail → notify + rollback option | S10 executes |
| 7. Confirm | If pass → log success | N/A |

---

## Phase 4: Candidate Protection

**Rule:** COPY candidate, never modify it.

```
COPY versions/vX.X-CANDIDATE/README.md → vault/README.md
Populate ONLY vault/README.md (100%, PRODUCTION)
CANDIDATE stays: 0%, INITIALIZING, R01 only
```

| File | Modified? |
|------|-----------|
| vault/README.md | ✅ YES |
| vault/old_README.md | ❌ NO |
| vX.X-CANDIDATE/README.md | ❌ NEVER |

---

## Test Results Handling

**Pass:**
```
✅ DEPLOYED_SUCCESS - v1.1 active, 20/20 tests passed
```

**Fail:**
```
❌ FAILED_REGRESSION - moved to /versions/v1.1-FAILED_REGRESSION/
Options: rollback (recommended) | investigate | keep (risky)
```

---

## State Tracking

```json
{
  "migration_id": "mig_v1.0_to_v1.1",
  "current_phase": 5,
  "regression_status": "RUNNING"
}
```

---

## Key Learnings

- User approves BEFORE deployment
- Regression tests run AFTER deployment
- COPY, never MODIFY candidates
- Rollback always available via S10